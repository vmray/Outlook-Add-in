import { dialogFallback } from "./fallbackauthdialog.js";
import { forwardMailToMiddleTier } from "./middle-tier-calls";
import { handleClientSideErrors } from "./error-handler";

let retryGetMiddletierToken = 0;

export async function forwardMail(messageId, callback, onTokenAcquired) {
  try {
    let middletierToken;

    try {
      middletierToken = await Office.auth.getAccessToken({
        allowSignInPrompt: false
      });
    } catch (err) {
      console.warn("Silent SSO failed, retrying with signin prompt", err);
      middletierToken = await Office.auth.getAccessToken({
        allowSignInPrompt: true
      });
    }

    if (onTokenAcquired) {
      onTokenAcquired();
    }

    let response = await forwardMailToMiddleTier(middletierToken, messageId);

    if (!response) {
      throw new Error("No response received from server.");
    }

    if (response.claims) {
      try {
        const mfaToken = await Office.auth.getAccessToken({
          authChallenge: response.claims,
        });
        response = await forwardMailToMiddleTier(mfaToken, messageId);
      } catch (mfaError) {
        console.warn("Claims challenge failed, falling back to dialog auth.", mfaError);
        retryGetMiddletierToken = 0;
        await dialogFallback(callback, messageId, onTokenAcquired);
        return;
      }
    }

    if (response.forward?.success === false) {
      await handleAADErrors(response, callback, messageId, onTokenAcquired);
      return;
    }

    retryGetMiddletierToken = 0;
    callback(response);

  } catch (exception) {
    console.error("forwardMail auth flow failed", exception);

    const clientErrorResult = handleClientSideErrors(exception);
    if (clientErrorResult.invokeFallBackDialog) {
      retryGetMiddletierToken = 0;
      await dialogFallback(callback, messageId, onTokenAcquired);
      return;
    }

    retryGetMiddletierToken = 0;
    callback({
      forward: {
        success: false,
        error: clientErrorResult.message || "Unable to authenticate your session. Please try again."
      }
    });
    return;
  }
}

async function handleAADErrors(response, callback, messageId, onTokenAcquired) {
  const errorText = response?.forward?.error || "";

  if (
    errorText.includes("AADSTS500133") &&
    retryGetMiddletierToken === 0
  ) {
    retryGetMiddletierToken++;

    try {
      const newToken = await Office.auth.getAccessToken({
        allowSignInPrompt: true
      });

      const retryResponse = await forwardMailToMiddleTier(newToken, messageId);

      if (retryResponse?.forward?.success === false) {
        throw new Error(retryResponse.forward.error || "Retry failed");
      }

      retryGetMiddletierToken = 0;
      callback(retryResponse);
      return;
    } catch (exception) {
      console.error("Authentication retry failed", exception);
    }
  }

  retryGetMiddletierToken = 0;
  await dialogFallback(callback, messageId, onTokenAcquired);
}