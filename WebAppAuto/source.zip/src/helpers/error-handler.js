export function handleClientSideErrors(error) {
  switch (error.code) {
    case 13001:
      // No one signed in to office
      return {
        invokeFallBackDialog: true,
        message: null
      };

    case 13002:
      return {
        invokeFallBackDialog: false,
        message: "❌ Permission request was cancelled. Please try again."
      };

    case 13006:
      return {
        invokeFallBackDialog: false,
        message: "❌ Office on the Web is experiencing an issue. Please refresh and try again."
      };

    case 13008:
      return {
        invokeFallBackDialog: false,
        message: "⏳ Office is completing a previous operation. Please try again in a moment."
      };

    case 13010:
      return {
        invokeFallBackDialog: false,
        message: "❌ Browser configuration issue detected. Please try again or contact IT support."
      };

    default:
      return {
        invokeFallBackDialog: false,
        message: "Unable to authenticate your session. Please try again."
      };
  }
}