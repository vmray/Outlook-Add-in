require("dotenv").config();
import * as createError from "http-errors";
import * as fs from "fs";
import * as path from "path";
import * as cookieParser from "cookie-parser";
import * as logger from "morgan";
import express from "express";

import { forwardMail, isValidRecipient } from "./msgraph-helper";
import { validateJwt } from "./ssoauth-helper";

const app = express();
const port = process.env.PORT || 3000;

app.set("port", port);

app.use(logger(process.env.NODE_ENV === "production" ? "combined" : "dev"));
app.use(cookieParser());
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ limit: "1mb", extended: true }));

app.use(express.static(path.join(process.cwd(), "dist")));
console.log("Serving static from:", path.join(process.cwd(), "dist"));

const indexRouter = express.Router();
indexRouter.get("/", function (req, res) {
  res.status(404).send("Not intended for browser use");
});

// Route APIs
indexRouter.get("/runtime-config.js", function (req, res) {
  res.type("application/javascript");
  res.setHeader("Cache-Control", "no-store");
  res.send(`
    window.APP_CONFIG = {
      clientId: "${process.env.CLIENT_ID}",
      tenantId: "${process.env.TENANT_ID}",
      domain: "${process.env.APP_DOMAIN}"
    };
  `);
});

indexRouter.get("/health", function (req, res) {
  res.status(200).json({
    status: "ok",
    uptime: process.uptime(),
    timestamp: new Date().toISOString()
  });
});

indexRouter.get("/manifest.xml", function (req, res) {
  const domain = process.env.APP_DOMAIN;
  const clientId = process.env.CLIENT_ID;

  if (!domain || !clientId) {
    return res.status(500).type("text/plain").send(
      "Manifest not available: APP_DOMAIN or CLIENT_ID is not configured on the server."
    );
  }

  const templatePath = path.join(process.cwd(), "dist", "manifest.template.xml");

  fs.readFile(templatePath, "utf8", (err, template) => {
    if (err) {
      console.error("Failed to read manifest template:", err);
      return res.status(500).type("text/plain").send("Manifest template not found.");
    }

    const applicationIdUri = `api://${domain}/${clientId}`;

    const rendered = template
      .replace(/\{YOUR_DOMAIN\}/g, domain)
      .replace(/\{APPLICATION_ID_URI\}/g, applicationIdUri)
      .replace(/\{CLIENT_ID\}/g, clientId);

    res.type("application/xml");
    res.setHeader("Cache-Control", "no-store");
    res.setHeader("Content-Disposition", "attachment; filename=\"manifest.xml\"");
    res.send(rendered);
  });
});

indexRouter.get("/diagnostics", function (req, res) {
  const required = ["CLIENT_ID", "TENANT_ID", "CLIENT_SECRET", "APP_DOMAIN", "RECIPIENT"];
  const envStatus = {};
  let envOk = true;

  for (const name of required) {
    const present = Boolean(process.env[name] && String(process.env[name]).trim() !== "");
    envStatus[name] = present ? "set" : "missing";
    if (!present) envOk = false;
  }

  const recipient = process.env.RECIPIENT;
  const recipientCheck = recipient && isValidRecipient(recipient)
    ? { status: "ok" }
    : { status: "invalid", reason: "Recipient must be an address under ir-mailbox.vmray.com" };

  const templatePath = path.join(process.cwd(), "dist", "manifest.template.xml");
  const manifestCheck = fs.existsSync(templatePath)
    ? { status: "ok", path: templatePath }
    : { status: "missing", path: templatePath };

  const moveFolderRaw = process.env.MOVE_REPORTED_PHISHING_EMAILS_TO_FOLDER;
  const moveFolder = String(moveFolderRaw).toLowerCase() === "true";

  const overall = envOk && recipientCheck.status === "ok" && manifestCheck.status === "ok"
    ? "ok"
    : "error";

  res.status(overall === "ok" ? 200 : 500).json({
    status: overall,
    timestamp: new Date().toISOString(),
    checks: {
      env: { status: envOk ? "ok" : "error", details: envStatus },
      recipient: recipientCheck,
      manifestTemplate: manifestCheck,
      moveReportedEmailsToFolder: moveFolder
    },
    manifestUrl: process.env.APP_DOMAIN
      ? `https://${process.env.APP_DOMAIN}/manifest.xml`
      : null
  });
});

indexRouter.post("/forwardMail", validateJwt, forwardMail);


app.use("/", indexRouter);

// Catch 404 and forward to error handler
app.use(function (req, res, next) {
  console.warn("404:", req.originalUrl);
  next(createError(404));
});

// error handler
app.use(function (err, req, res, next) {
  console.error("500: ", err);
  // render the error page
  res.status(err.status || 500).send({
    message: err.message,
  });
});

app.listen(port, () => console.log("Server listening on port: " + port));